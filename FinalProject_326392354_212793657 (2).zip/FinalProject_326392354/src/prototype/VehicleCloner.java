package prototype;

import model.Car;

public class VehicleCloner {
    public Car cloneVehicle(Car original) {
        return original.clone();
    }
}
