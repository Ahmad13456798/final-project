package test;

import model.Car;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class CarTest {

    @Test
    void testCalculateDurationMinutes() {

        LocalDateTime entryTime = LocalDateTime.now().minusMinutes(30);
        LocalDateTime exitTime = LocalDateTime.now();

        Car car = new Car("123456", entryTime);
        car.setExitTime(exitTime);

        long duration = car.calculateDurationMinutes();
        assertTrue(duration >= 29 && duration <= 31);
    }

    @Test
    void testClone() {
        Car original = new Car("ABC123", LocalDateTime.now());
        Car clone = original.clone();

        assertNotSame(original, clone);
        assertEquals(original.getLicense(), clone.getLicense());
        assertEquals(original.getEntryTime(), clone.getEntryTime());
    }

    @Test
    void testToStringContainsLicense() {
        Car car = new Car("XYZ999", LocalDateTime.now());
        String result = car.toString();
        assertTrue(result.contains("XYZ999"));
    }
}
