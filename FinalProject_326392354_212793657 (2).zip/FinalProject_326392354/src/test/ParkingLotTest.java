package test;

import model.Car;
import model.ParkingLot;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class ParkingLotTest {

    @Test
    void testAddCarSuccess() {
        ParkingLot lot = new ParkingLot(2, 0.5);
        Car car = new Car("111111", LocalDateTime.now());

        boolean added = lot.addCar(car);
        assertTrue(added, "הרכב היה אמור להיכנס בהצלחה");
    }

    @Test
    void testAddCarFailWhenFull() {
        ParkingLot lot = new ParkingLot(1, 0.5);
        lot.addCar(new Car("A", LocalDateTime.now()));
        boolean result = lot.addCar(new Car("B", LocalDateTime.now()));

        assertFalse(result, "לא אמור להיות מקום פנוי");
    }

    @Test
    void testRemoveCar() {
        ParkingLot lot = new ParkingLot(1, 0.5);
        Car car = new Car("777777", LocalDateTime.now().minusMinutes(10));
        lot.addCar(car);

        boolean removed = lot.removeCar("777777");
        assertTrue(removed, "הרכב היה אמור לצאת בהצלחה");
    }

    @Test
    void testFindCarByLicense() {
        ParkingLot lot = new ParkingLot(2, 0.5);
        Car car = new Car("XYZ123", LocalDateTime.now());
        lot.addCar(car);

        Car found = lot.findCarByLicense("XYZ123");
        assertNotNull(found);
        assertEquals("XYZ123", found.getLicense());
    }
}
