package model;

import java.time.Duration;
import java.time.LocalDateTime;

public class Car implements Cloneable {
    private String license;
    private LocalDateTime entryTime;
    private LocalDateTime exitTime;

    public Car(String license, LocalDateTime entryTime) {
        this.license = license;
        this.entryTime = entryTime;
        this.exitTime = null;
    }

    public String getLicense() {
        return license;
    }

    public LocalDateTime getEntryTime() {
        return entryTime;
    }

    public LocalDateTime getExitTime() {
        return exitTime;
    }

    public void setExitTime(LocalDateTime exitTime) {
        this.exitTime = exitTime;
    }

    public long calculateDurationMinutes() {
        if (exitTime == null) return 0;
        Duration duration = Duration.between(entryTime, exitTime);
        return duration.toMinutes();
    }

    @Override
    public Car clone() {
        try {
            return (Car) super.clone();
        } catch (CloneNotSupportedException e) {
            return new Car(this.license, this.entryTime);
        }
    }

    @Override
    public String toString() {
        return "Car{" +
                "license='" + license + '\'' +
                ", entryTime=" + entryTime +
                ", exitTime=" + exitTime +
                '}';
    }
}
