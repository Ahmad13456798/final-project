package model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ParkingLot {
    private List<ParkingSpot> spots;
    private double pricePerMinute;

    public ParkingLot(int totalSpots, double pricePerMinute) {
        this.pricePerMinute = pricePerMinute;
        this.spots = new ArrayList<>();
        for (int i = 1; i <= totalSpots; i++) {
            spots.add(new ParkingSpot(i));
        }
    }

    public boolean addCar(Car car) {
        for (ParkingSpot spot : spots) {
            if (!spot.isOccupied()) {
                spot.assignCar(car);
                return true;
            }
        }
        return false;
    }
    public List<ParkingSpot> getSpots() {
        return spots;
    }

    public Car findCarByLicense(String license) {
        for (ParkingSpot spot : spots) {
            if (spot.isOccupied() && spot.getParkedCar().getLicense().equals(license)) {
                return spot.getParkedCar();
            }
        }
        return null;
    }

    public boolean removeCar(String license) {
        for (ParkingSpot spot : spots) {
            if (spot.isOccupied() && spot.getParkedCar().getLicense().equals(license)) {
                Car car = spot.getParkedCar();
                car.setExitTime(LocalDateTime.now());

                long minutes = car.calculateDurationMinutes();
                double cost = minutes * pricePerMinute;

                System.out.println("רכב " + license + " יצא. זמן חניה: " + minutes + " דקות. עלות: " + cost + " ש\"ח");

                spot.releaseCar();
                return true;
            }
        }
        return false;
    }

    public int getAvailableSpots() {
        int count = 0;
        for (ParkingSpot spot : spots) {
            if (!spot.isOccupied()) count++;
        }
        return count;
    }

    public void printStatus() {
        System.out.println("מצב חניון:");
        for (ParkingSpot spot : spots) {
            System.out.println(spot);
        }
    }
}
