package model;

public class ParkingSpot {
    private int spotNumber;
    private boolean isOccupied;
    private Car parkedCar;

    public ParkingSpot(int spotNumber) {
        this.spotNumber = spotNumber;
        this.isOccupied = false;
        this.parkedCar = null;
    }

    public int getSpotNumber() {
        return spotNumber;
    }

    public boolean isOccupied() {
        return isOccupied;
    }

    public Car getParkedCar() {
        return parkedCar;
    }

    public void assignCar(Car car) {
        this.parkedCar = car;
        this.isOccupied = true;
    }

    public void releaseCar() {
        this.parkedCar = null;
        this.isOccupied = false;
    }

    @Override
    public String toString() {
        return "ParkingSpot{" +
                "spotNumber=" + spotNumber +
                ", isOccupied=" + isOccupied +
                ", parkedCar=" + (parkedCar != null ? parkedCar.getLicense() : "None") +
                '}';
    }
}
