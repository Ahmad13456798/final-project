package observer;

public interface ParkingObserver {
    void update(String message);
}
