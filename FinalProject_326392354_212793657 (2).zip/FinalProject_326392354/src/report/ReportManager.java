package report;

import model.Car;
import model.ParkingSpot;

import java.util.List;

public class ReportManager {

    public double calculateDailyRevenue(List<ParkingSpot> spots, double pricePerMinute) {
        double total = 0;
        for (ParkingSpot spot : spots) {
            if (!spot.isOccupied() && spot.getParkedCar() != null) {
                Car car = spot.getParkedCar();
                long minutes = car.calculateDurationMinutes();
                total += minutes * pricePerMinute;
            }
        }
        return total;
    }

    public double calculateAverageParkingTime(List<ParkingSpot> spots) {
        long totalMinutes = 0;
        int count = 0;

        for (ParkingSpot spot : spots) {
            Car car = spot.getParkedCar();
            if (car != null && car.getExitTime() != null) {
                totalMinutes += car.calculateDurationMinutes();
                count++;
            }
        }

        return (count > 0) ? (double) totalMinutes / count : 0;
    }
}
