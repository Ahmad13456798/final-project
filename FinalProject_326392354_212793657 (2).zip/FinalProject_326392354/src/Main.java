import factory.ParkingFactory;
import model.Car;
import model.ParkingLot;
import prototype.VehicleCloner;
import report.ReportManager;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ParkingLot parkingLot = new ParkingLot(5, 0.5);   
        ReportManager reportManager = new ReportManager();
        VehicleCloner cloner = new VehicleCloner();

        while (true) {
            System.out.println("\n----- מערכת ניהול חניון -----");
            System.out.println("1. הוסף רכב");
            System.out.println("2. הוצא רכב");
            System.out.println("3. הצג מצב חניון");
            System.out.println("4. הפק דוח (רווח + ממוצע זמן)");
            System.out.println("5. שכפול רכב");
            System.out.println("6. יציאה");
            System.out.print("בחירה: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1:
                    System.out.print("מספר רכב: ");
                    String licenseIn = scanner.nextLine();
                    Car carIn = ParkingFactory.createCar(licenseIn);
                    if (parkingLot.addCar(carIn)) {
                        System.out.println("✅ רכב נכנס בהצלחה.");
                    } else {
                        System.out.println("❌ אין מקומות פנויים.");
                    }
                    break;

                case 2: // הוצאת רכב
                    System.out.print("מספר רכב להוצאה: ");
                    String licenseOut = scanner.nextLine();
                    if (!parkingLot.removeCar(licenseOut)) {
                        System.out.println("❌ הרכב לא נמצא.");
                    }
                    break;

                case 3:
                    parkingLot.printStatus();
                    break;

                case 4:
                    double revenue = reportManager
                            .calculateDailyRevenue(parkingLot.getSpots(), 0.5);
                    double avgTime = reportManager
                            .calculateAverageParkingTime(parkingLot.getSpots());
                    System.out.printf("💰 רווח יומי: %.2f ₪%n", revenue);
                    System.out.printf("⏱ ממוצע זמן חניה: %.1f דקות%n", avgTime);
                    break;

                case 5:
                    System.out.print("מספר רכב לשכפול: ");
                    String licenseClone = scanner.nextLine();
                    Car original = parkingLot.findCarByLicense(licenseClone);
                    if (original != null) {
                        Car copy = cloner.cloneVehicle(original);
                        System.out.println("🎯 רכב שוכפל: " + copy);
                    } else {
                        System.out.println("❌ רכב לא נמצא.");
                    }
                    break;

                case 6:
                    System.out.println("להתראות 👋");
                    return;

                default:
                    System.out.println("בחירה לא חוקית.");
            }
        }
    }
}
