package factory;

import model.Car;
import model.ParkingSpot;

import java.time.LocalDateTime;

public class ParkingFactory {

    public static Car createCar(String license) {
        return new Car(license, LocalDateTime.now());
    }

    public static ParkingSpot createSpot(int spotNumber) {
        return new ParkingSpot(spotNumber);
    }
}
